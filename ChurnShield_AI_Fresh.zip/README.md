# ChurnShield AI — Customer Churn Prediction and Analytics

An MCA Machine Learning Lab mini-project that predicts telecom churn, compares five classification models, segments customers using K-Means, and records predictions in SQLite.

## Features
- Dashboard with churn, tenure, contracts and billing charts
- CSV upload and dataset inspection
- Preprocessing via sklearn pipelines, stratified 80/20 train/test split
- Logistic Regression, Decision Tree, Random Forest, SVM, KNN
- Accuracy, precision, recall, F1, ROC-AUC, confusion matrices and ROC curves
- Optional Random Forest tuning and permutation importance
- Individual customer predictions with risk categories
- K-Means segmentation and PCA visualization
- SQLite prediction history with CSV export

## Installation (Windows PowerShell)
From the project folder:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m streamlit run app.py
```

## Dataset
The app starts with 650 **synthetic demonstration** customers, created deterministically. You can upload the IBM Telco Customer Churn CSV (with its standard columns). Uploaded data must include all feature columns and the `Churn` target. This is a supervised learning demonstration, not a production customer-retention system. Results on synthetic data do not establish real-world predictive accuracy.

## Files
- `app.py`: Streamlit pages and charts
- `ml_engine.py`: data generation, preprocessing, training, evaluation, clustering
- `database.py`: SQLite storage
- `requirements.txt`: Python dependencies

`models/` and `churnshield.db` are generated automatically. Trained model caches are specific to dataset contents. **Only load trusted local Joblib files**; Joblib/pickle files can execute code on loading.

## Troubleshooting
- `ModuleNotFoundError`: run the install command again in the same project folder.
- Missing CSV columns: use the original IBM Telco schema, including `Churn`.
- Training is slow: leave optional tuning off; SVM training can take time on large datasets.
- No real dataset: simply launch the app and use the synthetic demo.
