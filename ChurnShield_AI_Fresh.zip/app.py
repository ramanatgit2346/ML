import json
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import streamlit as st
from database import initialize, save_prediction, history
from ml_engine import (FEATURES,NUMERIC,CATEGORICAL,ALGORITHMS,synthetic_data,prepare,train,load_cached,importance,segments)

st.set_page_config(page_title='ChurnShield AI',page_icon='🛡️',layout='wide')
st.markdown('''<style>.block-container{padding-top:1.5rem}h1{color:#2176bb}div[data-testid="stMetric"]{border:1px solid #dae3ed;border-radius:12px;padding:14px}</style>''',unsafe_allow_html=True)
initialize()
st.title('🛡️ ChurnShield AI')
st.caption('Customer churn prediction, model comparison and segmentation • Academic demonstration')

@st.cache_data
def demo(): return synthetic_data()

@st.cache_data
def read_csv(data):
    import io
    return pd.read_csv(io.BytesIO(data))

with st.sidebar:
    st.header('Navigation')
    page=st.radio('Go to', ['Dashboard','Dataset Explorer','Churn Prediction','Model Comparison','Customer Segmentation','Prediction History'])
    uploaded=st.file_uploader('Upload IBM Telco-format CSV',type='csv')
    st.caption('Upload a labeled dataset or use generated synthetic demonstration records.')

try:
    raw=read_csv(uploaded.getvalue()) if uploaded else demo()
    df=prepare(raw)
except Exception as exc:
    st.error(f'Dataset error: {exc}')
    st.stop()
if uploaded is None: st.info('Using **synthetic demonstration data**, not real telecom customer records.')

@st.cache_resource(show_spinner='Training models (first run may take a moment)...')
def get_bundle(_df, dataset_key, tuned):
    cached=load_cached(_df,tuned)
    return cached if cached is not None else train(_df,tuned)

from ml_engine import fingerprint
key=fingerprint(df)

def chart(fig):
    st.pyplot(fig,use_container_width=True)
    plt.close(fig)

def show_bar(counts,title):
    fig,ax=plt.subplots(figsize=(7,3.5))
    counts.plot(kind='bar',ax=ax,color='#2176bb')
    ax.set_title(title); ax.tick_params(axis='x',rotation=25)
    fig.tight_layout(); chart(fig)

if page=='Dashboard':
    st.header('Customer Overview')
    a,b,c,d=st.columns(4)
    a.metric('Total customers',f'{len(df):,}')
    b.metric('Churned customers',f'{int(df.Churn.sum()):,}')
    c.metric('Churn rate',f'{df.Churn.mean():.1%}')
    d.metric('Average monthly charges',f'${df.MonthlyCharges.mean():,.2f}')
    l,r=st.columns(2)
    with l:
        show_bar(df.Churn.map({0:'No',1:'Yes'}).value_counts(),'Churn Distribution')
        show_bar(df.Contract.value_counts(),'Contract Types')
    with r:
        fig,ax=plt.subplots(figsize=(7,3.5)); sns.histplot(data=df,x='MonthlyCharges',hue='Churn',bins=25,ax=ax); ax.set_title('Monthly Charges by Churn'); fig.tight_layout(); chart(fig)
        fig,ax=plt.subplots(figsize=(7,3.5)); sns.boxplot(data=df,x='Churn',y='tenure',ax=ax); ax.set_xticks([0,1],['No','Yes']); ax.set_title('Tenure by Churn'); fig.tight_layout(); chart(fig)
elif page=='Dataset Explorer':
    st.header('Dataset Explorer')
    st.dataframe(raw.head(100),use_container_width=True)
    a,b,c=st.columns(3); a.metric('Rows',len(raw)); b.metric('Columns',len(raw.columns)); c.metric('Duplicate rows',int(raw.duplicated().sum()))
    st.subheader('Missing values (raw dataset)')
    missing=raw.replace(r'^\s*$',pd.NA,regex=True).isna().sum().sort_values(ascending=False)
    st.dataframe(missing.rename('Missing').to_frame(),use_container_width=True)
    st.subheader('Column types'); st.dataframe(raw.dtypes.astype(str).rename('Type').to_frame())
    st.subheader('Numerical statistics'); st.dataframe(df[NUMERIC].describe())
    st.subheader('Numerical correlations')
    fig,ax=plt.subplots(figsize=(7,4)); sns.heatmap(df[NUMERIC+['Churn']].corr(),annot=True,cmap='Blues',ax=ax); fig.tight_layout(); chart(fig)
elif page=='Model Comparison':
    st.header('Model Comparison')
    tuned=st.checkbox('Lightweight Random Forest hyperparameter tuning (slower)')
    if st.button('Train / load models',type='primary'):
        try: st.session_state['trained_key']=(key,tuned)
        except Exception as exc: st.error(str(exc))
    if st.session_state.get('trained_key')==(key,tuned):
        try:
            bundle=get_bundle(df,key,tuned)
            st.success('Models are ready. Best by F1: '+bundle['best'])
            st.dataframe(bundle['scores'].style.format({c:'{:.3f}' for c in ['Accuracy','Precision','Recall','F1','ROC-AUC']}),use_container_width=True)
            fig,axes=plt.subplots(1,2,figsize=(11,4))
            for ax,metric in zip(axes,['Accuracy','F1']):
                sns.barplot(data=bundle['scores'],x=metric,y='Algorithm',ax=ax,color='#2176bb'); ax.set_xlim(0,1)
            fig.tight_layout(); chart(fig)
            chosen=st.selectbox('Inspect algorithm',ALGORITHMS)
            fig,ax=plt.subplots(figsize=(5,4)); sns.heatmap(bundle['evaluation'][chosen]['matrix'],annot=True,fmt='d',cmap='Blues',xticklabels=['No','Yes'],yticklabels=['No','Yes'],ax=ax); ax.set(xlabel='Predicted',ylabel='Actual',title=f'{chosen} Confusion Matrix'); chart(fig)
            fig,ax=plt.subplots(figsize=(7,4))
            for name,item in bundle['evaluation'].items():
                fpr,tpr,_=item['roc']; ax.plot(fpr,tpr,label=name)
            ax.plot([0,1],[0,1],'k--'); ax.set(xlabel='False positive rate',ylabel='True positive rate',title='ROC Curves'); ax.legend(fontsize=8); fig.tight_layout(); chart(fig)
            st.subheader('Feature importance (permutation-based)')
            if st.button('Calculate feature importance'):
                with st.spinner('Calculating...'):
                    st.bar_chart(importance(bundle['models'][bundle['best']],df).head(12))
        except Exception as exc: st.error(f'Model error: {exc}')
    else: st.info('Select Train / load models to evaluate all five classifiers.')
elif page=='Churn Prediction':
    st.header('Predict Customer Churn')
    st.caption('The prediction uses a trained ML pipeline. Probability thresholds: Low < 30%, Medium 30–60%, High ≥ 60%.')
    try: bundle=get_bundle(df,key,False)
    except Exception as exc: st.error(f'Training failed: {exc}'); st.stop()
    algorithm=st.selectbox('Algorithm',ALGORITHMS,index=ALGORITHMS.index(bundle['best']))
    with st.form('predict'):
        values={}; left,right=st.columns(2)
        for i,col in enumerate(FEATURES):
            with (left if i%2==0 else right):
                if col in NUMERIC:
                    median=float(df[col].median())
                    if col in ['SeniorCitizen','tenure']:
                        values[col]=st.number_input(col,min_value=0,max_value=1 if col=='SeniorCitizen' else 100,value=int(median),step=1)
                    else: values[col]=st.number_input(col,min_value=0.0,value=round(median,2),step=1.0)
                else:
                    opts=sorted(df[col].dropna().astype(str).unique().tolist())
                    values[col]=st.selectbox(col,opts)
        submit=st.form_submit_button('Predict churn',type='primary')
    if submit:
        try:
            model=bundle['models'][algorithm]
            prob=float(model.predict_proba(pd.DataFrame([values]))[0,list(model.classes_).index(1)])
            result='Yes' if int(model.predict(pd.DataFrame([values]))[0])==1 else 'No'
            risk='Low' if prob<.3 else 'Medium' if prob<.6 else 'High'
            a,b,c=st.columns(3); a.metric('Predicted Churn',result); b.metric('Churn Probability',f'{prob:.1%}'); c.metric('Risk Level',risk)
            st.progress(prob)
            st.caption('Risk levels summarize predicted probability, not a guarantee. Review tenure, contract and billing factors using dataset charts and model feature importance.')
            save_prediction(json.dumps(values),result,prob,algorithm)
            st.success('Prediction saved to history.')
        except Exception as exc: st.error(f'Prediction error: {exc}')
elif page=='Customer Segmentation':
    st.header('K-Means Customer Segmentation')
    k=st.slider('Number of clusters',2,6,3)
    try:
        clustered,coords=segments(df,k)
        fig,ax=plt.subplots(figsize=(9,5)); sns.scatterplot(data=coords,x='PC1',y='PC2',hue='Cluster',palette='tab10',alpha=.7,ax=ax); ax.set_title('PCA Projection of Customer Segments'); fig.tight_layout(); chart(fig)
        summary=clustered.groupby('Cluster').agg(Customers=('Churn','size'),Churn_Rate=('Churn','mean'),Average_Tenure=('tenure','mean'),Average_Monthly_Charges=('MonthlyCharges','mean'))
        st.dataframe(summary.style.format({'Churn_Rate':'{:.1%}','Average_Tenure':'{:.1f}','Average_Monthly_Charges':'${:.2f}'}),use_container_width=True)
        st.caption('Clusters are descriptive patterns, not validated customer personas or churn predictions.')
    except Exception as exc: st.error(f'Clustering error: {exc}')
else:
    st.header('Prediction History')
    records=history()
    if records.empty: st.info('No predictions saved yet.')
    else:
        st.dataframe(records,use_container_width=True)
        st.download_button('Export history CSV',records.to_csv(index=False).encode(),file_name='prediction_history.csv',mime='text/csv')
