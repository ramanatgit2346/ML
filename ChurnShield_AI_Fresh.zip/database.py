import sqlite3
from pathlib import Path
import pandas as pd

DB = Path(__file__).resolve().parent / 'churnshield.db'

def initialize():
    with sqlite3.connect(DB) as con:
        con.execute('''CREATE TABLE IF NOT EXISTS prediction_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            inputs TEXT NOT NULL,
            prediction TEXT NOT NULL,
            probability REAL NOT NULL,
            algorithm TEXT NOT NULL)''')

def save_prediction(inputs, prediction, probability, algorithm):
    with sqlite3.connect(DB) as con:
        con.execute('INSERT INTO prediction_history(inputs,prediction,probability,algorithm) VALUES (?,?,?,?)',
                    (inputs, prediction, float(probability), algorithm))

def history():
    with sqlite3.connect(DB) as con:
        return pd.read_sql_query('SELECT * FROM prediction_history ORDER BY id DESC', con)
