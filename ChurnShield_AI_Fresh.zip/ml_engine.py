from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, roc_curve

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / 'models'
MODEL_DIR.mkdir(exist_ok=True)
FEATURES = ['gender','SeniorCitizen','Partner','Dependents','tenure','PhoneService','MultipleLines','InternetService','OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies','Contract','PaperlessBilling','PaymentMethod','MonthlyCharges','TotalCharges']
NUMERIC = ['SeniorCitizen','tenure','MonthlyCharges','TotalCharges']
CATEGORICAL = [c for c in FEATURES if c not in NUMERIC]
ALGORITHMS = ['Logistic Regression','Decision Tree','Random Forest','SVM','KNN']

def synthetic_data(n=650):
    rng = np.random.default_rng(42)
    df = pd.DataFrame({'customerID':[f'SYN-{i:05d}' for i in range(n)],
        'gender':rng.choice(['Male','Female'],n), 'SeniorCitizen':rng.binomial(1,.17,n),
        'Partner':rng.choice(['Yes','No'],n),'Dependents':rng.choice(['Yes','No'],n),
        'tenure':rng.integers(0,73,n),'PhoneService':rng.choice(['Yes','No'],n,p=[.9,.1]),
        'InternetService':rng.choice(['DSL','Fiber optic','No'],n,p=[.35,.45,.2]),
        'Contract':rng.choice(['Month-to-month','One year','Two year'],n,p=[.55,.25,.2]),
        'PaperlessBilling':rng.choice(['Yes','No'],n),
        'PaymentMethod':rng.choice(['Electronic check','Mailed check','Bank transfer (automatic)','Credit card (automatic)'],n),
        'MonthlyCharges':rng.uniform(20,115,n).round(2)})
    df['MultipleLines'] = np.where(df.PhoneService=='No','No phone service',rng.choice(['Yes','No'],n))
    for c in ['OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies']:
        df[c] = np.where(df.InternetService=='No','No internet service',rng.choice(['Yes','No'],n))
    df['TotalCharges'] = (df.tenure*df.MonthlyCharges + rng.normal(0,25,n)).clip(0).round(2)
    z = (-1.4 + 1.45*(df.Contract=='Month-to-month').astype(int) + .65*(df.InternetService=='Fiber optic').astype(int)
         + .55*(df.PaymentMethod=='Electronic check').astype(int) - .026*df.tenure + .008*(df.MonthlyCharges-60)
         - .35*(df.TechSupport=='Yes').astype(int))
    p = 1/(1+np.exp(-z))
    df['Churn'] = np.where(rng.random(n)<p,'Yes','No')
    return df

def prepare(df):
    df = df.copy()
    missing = [c for c in FEATURES+['Churn'] if c not in df.columns]
    if missing: raise ValueError('Missing required columns: '+', '.join(missing))
    df = df.drop_duplicates(subset=['customerID'] if 'customerID' in df else None)
    for c in NUMERIC: df[c] = pd.to_numeric(df[c],errors='coerce')
    for c in CATEGORICAL: df[c] = df[c].astype('string').replace({'':pd.NA,'nan':pd.NA})
    df['Churn'] = df.Churn.astype('string').str.strip().str.lower().map({'yes':1,'no':0,'1':1,'0':0})
    df = df.dropna(subset=['Churn'])
    if len(df)<30: raise ValueError('Need at least 30 valid customer records.')
    if df.Churn.nunique()!=2 or df.Churn.value_counts().min()<3: raise ValueError('Both churn classes need at least 3 records.')
    return df.reset_index(drop=True)

def preprocessing():
    numeric = Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())])
    categorical = Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('encode',OneHotEncoder(handle_unknown='ignore'))])
    return ColumnTransformer([('num',numeric,NUMERIC),('cat',categorical,CATEGORICAL)])

def candidates():
    return {'Logistic Regression':LogisticRegression(max_iter=1200,random_state=42),
        'Decision Tree':DecisionTreeClassifier(max_depth=7,min_samples_leaf=4,random_state=42),
        'Random Forest':RandomForestClassifier(n_estimators=90,max_depth=12,min_samples_leaf=3,random_state=42,n_jobs=-1),
        'SVM':SVC(probability=True,random_state=42), 'KNN':KNeighborsClassifier(n_neighbors=9)}

def fingerprint(df):
    return hashlib.sha256(pd.util.hash_pandas_object(df[FEATURES+['Churn']],index=True).values.tobytes()).hexdigest()[:16]

def train(df, tune=False):
    df=prepare(df)
    xtr,xte,ytr,yte=train_test_split(df[FEATURES],df.Churn.astype(int),test_size=.2,stratify=df.Churn,random_state=42)
    rows=[]; fitted={}; evaluations={}
    for name, estimator in candidates().items():
        pipe=Pipeline([('prep',preprocessing()),('model',estimator)])
        if tune and name=='Random Forest':
            pipe=GridSearchCV(pipe,{'model__max_depth':[6,12],'model__min_samples_leaf':[2,5]},cv=StratifiedKFold(3,shuffle=True,random_state=42),scoring='f1',n_jobs=-1)
        pipe.fit(xtr,ytr)
        model=pipe.best_estimator_ if isinstance(pipe,GridSearchCV) else pipe
        predictions=model.predict(xte)
        probabilities=model.predict_proba(xte)[:,list(model.classes_).index(1)]
        metrics={'Algorithm':name,'Accuracy':accuracy_score(yte,predictions),'Precision':precision_score(yte,predictions,zero_division=0),
            'Recall':recall_score(yte,predictions,zero_division=0),'F1':f1_score(yte,predictions,zero_division=0),
            'ROC-AUC':roc_auc_score(yte,probabilities)}
        rows.append(metrics); fitted[name]=model
        evaluations[name]={'matrix':confusion_matrix(yte,predictions,labels=[0,1]),'roc':roc_curve(yte,probabilities)}
    scores=pd.DataFrame(rows).sort_values(['F1','ROC-AUC'],ascending=False).reset_index(drop=True)
    best=scores.iloc[0]['Algorithm']; key=fingerprint(df)
    bundle={'models':fitted,'scores':scores,'evaluation':evaluations,'best':best,'fingerprint':key,'tuned':tune}
    joblib.dump(bundle,MODEL_DIR/f'{key}_{int(tune)}.joblib')
    return bundle

def load_cached(df,tune=False):
    path=MODEL_DIR/f'{fingerprint(prepare(df))}_{int(tune)}.joblib'
    return joblib.load(path) if path.exists() else None

def importance(model,df):
    df=prepare(df)
    sample=df.sample(min(len(df),180),random_state=42)
    result=permutation_importance(model,sample[FEATURES],sample.Churn.astype(int),n_repeats=3,random_state=42,scoring='f1')
    return pd.Series(result.importances_mean,index=FEATURES).sort_values(ascending=False)

def segments(df,k):
    df=prepare(df)
    x=preprocessing().fit_transform(df[FEATURES])
    if hasattr(x,'toarray'): x=x.toarray()
    labels=KMeans(n_clusters=k,random_state=42,n_init=10).fit_predict(x)
    coords=PCA(n_components=2,random_state=42).fit_transform(x)
    output=df.copy(); output['Cluster']=labels
    return output,pd.DataFrame({'PC1':coords[:,0],'PC2':coords[:,1],'Cluster':labels.astype(str)})
